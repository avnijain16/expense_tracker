const form = document.getElementById('transaction-form');
const desc = document.getElementById('desc');
const amount = document.getElementById('amount');
const balanceEl = document.getElementById('balance');
const list = document.getElementById('transaction-list');

let transactions = JSON.parse(localStorage.getItem('transactions')) || [];

function updateUI() {
  list.innerHTML = '';
  let total = 0;
  transactions.forEach((tx, index) => {
    const li = document.createElement('li');
    li.innerHTML = `${tx.desc} <span>${tx.amount}</span>`;
    list.appendChild(li);
    total += parseFloat(tx.amount);
  });
  balanceEl.innerText = total;
  localStorage.setItem('transactions', JSON.stringify(transactions));
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const tx = {
    desc: desc.value,
    amount: +amount.value
  };
  transactions.push(tx);
  desc.value = '';
  amount.value = '';
  updateUI();
});

updateUI();
